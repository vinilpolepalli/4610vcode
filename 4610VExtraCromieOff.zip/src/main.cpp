
/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
void drive(double distance, int speed)
{
  TopLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);
}
void turnRight(double distance, int speed)
{
  TopLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct);

}
void turnLeft(double distance, int speed)
{
  TopLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);

}

void driveReverse(double distance, int speed)
{
  TopLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomLeftMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  TopRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct,false);
  BottomRightMotor.spinFor(-distance, rotationUnits::rev, speed, velocityUnits::pct);
}
void shoot(double x, int y)
{
  LauncherTop.spinFor(x, rotationUnits::rev, y, velocityUnits::pct);
  LauncherBottom.spinFor(-x, rotationUnits::rev, y, velocityUnits::pct);
}
void spinarm(){
  if(handFeed.position(degrees)<60){
    handFeed.spinToPosition(100, rotationUnits::deg , 25, velocityUnits::pct);
  }
  else{
    handFeed.spinToPosition(-45, rotationUnits::deg , 25, velocityUnits::pct);
  }
}



void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  LauncherTop.setStopping(hold);
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  LauncherTop.setStopping(hold);
  drive(1.4,40);
  
  driveReverse(1.4,40);
 

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
int intake(){
  while(true){
    while(Controller1.ButtonLeft.pressing()){
      Intake.spin(forward, 100, percent);
    }
    while(Controller1.ButtonDown.pressing()){
      Intake.spin(reverse, 100, percent);
    }
    Intake.stop(hold);
  }
}
int wings(){
  while(true){
    while(Controller1.ButtonA.pressing()){
      RightWing.set(true);
      LeftWing.set(true);
    }
    while(Controller1.ButtonX.pressing()){
      RightWing.set(false);
      LeftWing.set(false);
    }
  }
}

void usercontrol(void) {
  // User control code here, inside the loop
  LauncherTop.setVelocity(100, pct);
  LauncherBottom.setVelocity(100, pct);
  thread w (wings);
  thread i (intake);
  while (1) {
    while (true) {
      // Tank drive control
      // Set the velocity of the left wheels based on the vertical position of
      // the left joystick
      Controller1.ButtonR2.pressed(spinarm); // Spins the arm
      /*
      if (Controller1.ButtonR1.pressing())
      {
         RightWing.set(true);
         LeftWing.set(true);
      }
      else 
      {
        RightWing.set(false);
        LeftWing.set(false);

      }
      */
      TopLeftMotor.setVelocity(Controller1.Axis3.position(), percent);
      TopRightMotor.setVelocity(Controller1.Axis3.position(), percent);
      // Set the velocity of the right wheels based on the vertical position of
      // the right joystick
      BottomRightMotor.setVelocity(Controller1.Axis2.position(), percent);
      BottomLeftMotor.setVelocity(Controller1.Axis2.position(), percent);
      // Spin the left and right wheels forward based on their set velocities
      TopLeftMotor.spin(forward);
      TopRightMotor.spin(forward);
      BottomLeftMotor.spin(forward);
      BottomRightMotor.spin(forward);
      // Shooter control
      
  
      // Check if the top-left trigger (ButtonL1) is pressed
      if (Controller1.ButtonL1.pressing()) {
        // Spin the shooter motors forward
        LauncherBottom.spin(forward);
        LauncherTop.spin(reverse);
      } else if (Controller1.ButtonL2.pressing())
      {
        // Stop the shooter motors if the top-left trigger is not pressed
        LauncherBottom.spin(reverse);
        LauncherTop.spin(forward);
      } else 
      {
        LauncherBottom.stop(coast);
        LauncherTop.stop(coast);
      }
      



      vex::task::sleep(20); // Sleep to prevent wasted resources
    }
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Run the pre-autonomous function
  pre_auton();

  // Set up callbacks for autonomous and driver control periods
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Prevent main from exiting with an infinite loop
  while (true) {
    vex::task::sleep(100); // Sleep to prevent wasted resources

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // .....................................
    // ...................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
    Competition.autonomous(autonomous);
    Competition.drivercontrol(usercontrol);

    // Run the pre-autonomous function.
    pre_auton();

    // Prevent main from exiting with an infinite loop.
    while (true) {
      wait(100, msec);
    }
  }
}
